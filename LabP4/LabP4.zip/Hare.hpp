//
//  Hare.hpp
//  LabP4
//
//  Created by Alex Berthon on 9/17/16.
//  Copyright © 2016 Alex Berthon. All rights reserved.
//

#ifndef Hare_hpp
#define Hare_hpp

#include <stdio.h>
#include "Animal.hpp"

class Hare : public Animal {
    
public:
    void moveHare();
};



#endif /* Hare_hpp */
