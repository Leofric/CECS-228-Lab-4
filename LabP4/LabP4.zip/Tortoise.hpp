//
//  Tortoise.hpp
//  LabP4
//
//  Created by Alex Berthon on 9/17/16.
//  Copyright © 2016 Alex Berthon. All rights reserved.
//

#ifndef Tortoise_hpp
#define Tortoise_hpp

#include <stdio.h>
#include "Animal.hpp"

class Tortoise : public Animal{
public:
    void moveTortoise();
};

#endif /* Tortoise_hpp */
